public class WithoutMain {

    static int x=m1();
    public static int m1()
    {
        System.out.println("I can print");
        System.exit(0);
        return 10;
    }

}
