public class Array {
    public static void main(String[] args) {
        //Declaring an array
        int arr[]={12,23,44,56,78};

        for(int i:arr){
            System.out.print(i+" ");
        }
    }
}
