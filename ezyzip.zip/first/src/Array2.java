public class Array2 {
    public static void main(String args []){
        int [][] x = new int[2][];
        x[0]=new int[2];
        x[1]=new int[3];
        System.out.println(x.length);
        int []y= {2,3,4,5,6};

        System.out.println(y);
    }
}
