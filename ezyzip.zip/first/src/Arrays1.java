public class Arrays1 {
    public static void main (String args[]){
        int[] a= new int[2];
        System.out.println(a.getClass().getName());
        byte[] b= new byte[5];
        System.out.println(b.getClass().getName());
        boolean[] c = new boolean[5];
        System.out.println(c.getClass().getName());
        System.out.println(args.length);



    }
}
