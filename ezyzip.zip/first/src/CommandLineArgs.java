public class CommandLineArgs {
    public static void main(String [] args){
        int n = Integer.parseInt(args[0]);
        System.out.println("the square of "+n+"is"+(n*n));
    }
}
