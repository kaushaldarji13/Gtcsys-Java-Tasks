public class Datatype {
    public static void main(String args[]){
        int x = 10;
        int y = 010;
        int z = 0x10;
       double d = 1.2e3;
       float f = 1.2e3F;
       char ch = 'k';

       char k = 97;
        char l = 0XFace;
        char m = 0777;
        char n = 65535;
        char nn = '\u0061';
        String kk="Kaushal";
        int i= 0B1111;
        double de = 1_51_555.7_8_6;

        System.out.println(x+" "+y+" "+z);
        System.out.println(d);
        System.out.println(ch);
        System.out.println(k);
        System.out.println(l);
        System.out.println(m);
        System.out.println(n);
        System.out.println(nn   );
        System.out.println("this is \' Symbol");
        System.out.println("this is \" Symbol");
        System.out.println("this is \" Symbol");
        System.out.println("this is \\ Symbol");
        System.out.println("c:\\Kaushal_darji");
        System.out.println("this is \n Symbol");
        System.out.println("this is \t Symbol");
        System.out.println("this is \r Symbol");
        System.out.println("this is \f Symbol");
        System.out.println(kk);
        System.out.println(i);
        System.out.println(de);
    }
}
