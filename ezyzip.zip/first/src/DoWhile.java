public class DoWhile {
    public static void main(String args[]){
       do {
           while (true)
               System.out.println("hello...");
       } while (false);
    }
}
