public class EqualityOpraters1 {
    public static void main(String args[]){
       String s1 = new String("Kaushal");
       String s2 = new String("Kaushal");
        System.out.println(s1==s2);
        System.out.println(s1.equals(s2));
    }
}
