public class ForLoopEx {
    public static void main(String args[]){

        int i=0;
        for(System.out.println("Hello boss u r Sleeping");i<3;i++){

            System.out.println("no boss u only sleeping");

        }
    }
}
