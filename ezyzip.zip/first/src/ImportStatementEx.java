import java.util.*;



public class ImportStatementEx {

    public static void main(String [] args){
        Date d = new Date();
    }
}
