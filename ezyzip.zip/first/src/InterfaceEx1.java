interface Left{
    public void m1();
}
interface Right{
    public void m1(int i);
}
class InterfaceEx1 implements Left,Right {
    public void m1(){

    }
    public void m1(int i){

    }
}
