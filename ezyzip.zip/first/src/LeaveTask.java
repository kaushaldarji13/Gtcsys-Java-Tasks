import java.util.Scanner;

public class LeaveTask {
    public static void main(String[] args) {
        //getting no of leaves from user
        Scanner n = new Scanner(System.in);
        System.out.println("Enter no of leaves :-");
        int no =n.nextInt();

        int [] date = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31};
        int [] holidays = {6,8,9};
        String [] days = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};



    }
}
