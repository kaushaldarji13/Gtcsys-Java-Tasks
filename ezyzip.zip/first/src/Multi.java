public class Multi{
    public static void main(String[] args) {
        int num =7;
        for (num=1; num<=10 ;num++) {
            for (int i = 1; i <= 10; i++) {
                System.out.println(num + "*" + i + "=" + num * i);

            }
            System.out.println(" ");
        }

    }
}
