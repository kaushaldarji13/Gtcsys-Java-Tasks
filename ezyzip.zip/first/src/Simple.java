public class Simple {
    public static void main(String[] args) {
        int a = 10;
        float f = a;
        double d = a;

        System.out.println(a);
        System.out.println(f);
        System.out.println(d);

    }
}
