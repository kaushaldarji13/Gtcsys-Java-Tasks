public class StaticModifier1 {
    public static void main(String[] args) {
        System.out.println("String []");
    }

    public static void main(int[] args) {
        System.out.println("int [] ");
    }
}
