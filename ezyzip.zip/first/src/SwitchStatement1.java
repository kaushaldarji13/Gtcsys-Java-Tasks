public class SwitchStatement1 {
    public static void main (String args []){
        byte b = 10;
        switch (b+1){
            case 10:
                System.out.println(10);
                break;
            case 100:
                System.out.println(100);
                break;
            case 1000:
                System.out.println(1000);
                break;
            case 97:
                System.out.println(97);
                break;
         /*   case 'a':
                System.out.println('a');
                break;*/
        }
    }
}
