public class Variables1 {
    int x = 10;
    public void m1(){
        System.out.println(x);
    }

    public static void main (String args[]){
      Variables1 v1 = new Variables1();
        System.out.println(v1.x);

        v1.m1();

    }
}
