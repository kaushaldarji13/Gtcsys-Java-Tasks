public class Variables2 {

    int x;
    double y;
    boolean z;
    String s;


    public static void main (String args[]){
        Variables2 v1 = new Variables2();
        System.out.println(v1.x);
        System.out.println(v1.y);
        System.out.println(v1.z);
        System.out.println(v1.s);



     }
}
