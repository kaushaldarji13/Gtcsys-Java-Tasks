public class Variables6 {
    public static void main(String args []){
         int  i;
        if (args.length >0){
            i=10;
        }
        else {
            i=20;
        }
        System.out.println(i);
    }

}
