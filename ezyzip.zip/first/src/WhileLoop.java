public class WhileLoop {
    public static void main(String args[]){
      /*  while (true){
            System.out.println("hello....");
        }
        System.out.println("Hi....");*/


        int a= 10, b= 20;
        while(a<b){
            System.out.println("hello");
        }
        System.out.println("Hi");


    }

}
